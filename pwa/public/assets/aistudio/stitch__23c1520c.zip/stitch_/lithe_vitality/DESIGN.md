---
name: Lithe Vitality
colors:
  surface: '#f8f9fc'
  surface-dim: '#d9dadd'
  surface-bright: '#f8f9fc'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3f6'
  surface-container: '#edeef1'
  surface-container-high: '#e7e8eb'
  surface-container-highest: '#e1e2e5'
  on-surface: '#191c1e'
  on-surface-variant: '#45474b'
  inverse-surface: '#2e3133'
  inverse-on-surface: '#f0f1f4'
  outline: '#76777c'
  outline-variant: '#c6c6cb'
  surface-tint: '#5b5e68'
  primary: '#090d15'
  on-primary: '#ffffff'
  primary-container: '#1f232b'
  on-primary-container: '#868a94'
  inverse-primary: '#c3c6d1'
  secondary: '#0058be'
  on-secondary: '#ffffff'
  secondary-container: '#2170e4'
  on-secondary-container: '#fefcff'
  tertiary: '#240200'
  on-tertiary: '#ffffff'
  tertiary-container: '#4b0900'
  on-tertiary-container: '#ea5c3c'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dfe2ed'
  primary-fixed-dim: '#c3c6d1'
  on-primary-fixed: '#181c23'
  on-primary-fixed-variant: '#434750'
  secondary-fixed: '#d8e2ff'
  secondary-fixed-dim: '#adc6ff'
  on-secondary-fixed: '#001a42'
  on-secondary-fixed-variant: '#004395'
  tertiary-fixed: '#ffdad2'
  tertiary-fixed-dim: '#ffb4a3'
  on-tertiary-fixed: '#3d0600'
  on-tertiary-fixed-variant: '#8c1900'
  background: '#f8f9fc'
  on-background: '#191c1e'
  surface-variant: '#e1e2e5'
typography:
  display-hero:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '800'
    lineHeight: 48px
  display-hero-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '800'
    lineHeight: 40px
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 30px
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '500'
    lineHeight: 24px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 14px
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  gutter: 0.75rem
  margin: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.875rem
  space-lg: 1.25rem
  space-xl: 1.75rem
---

## Brand & Style

This design system expresses an ultra-clean, welcoming, and high-clarity mobile wellness aesthetic. It centers on physical vitality made effortless, balancing gentle discipline with friendly encouragement. The visual mood is bright, airy, and tactile—eschewing clinical sterility in favor of soft sculptural surfaces, friendly mascot illustration integrations, and clear nutritional and biometric data visualization.

The design movement mixes **Minimalism** with modern **Soft Tactility**:
- Crisp, hyper-legible typographic hierarchy utilizing Persian font stacks (Vazirmatn / IRANSans) complemented by modern rounded sans-serifs for Latin numerals.
- Calming off-white spatial canvas that reduces glare and cognitive strain during repeated daily logs.
- Hyper-rounded container cards (`24px–28px` radius) functioning as tactile ceramic tiles.
- Micro-delight powered by circular radial arcs, energetic accent pigments (warm coral, electric cobalt, vibrant citrus), and a high-contrast charcoal pill button architecture.

## Colors

The palette operates on a high-contrast foundation with energetic functional accents:
- **Canvas Base (`#F4F5F8`)**: An ultra-clean cool off-white that establishes warmth, separation, and subtle atmosphere behind foreground containers.
- **Card Surface (`#FFFFFF`)**: Pure crisp white used across cards, badges, and nested tracking pods to yield stark contrast over the canvas base without harsh outline borders.
- **Primary / Dominant Charcoal (`#1F232B`)**: Deep ink-slate utilized for high-priority CTA pill buttons, prominent numerical counters, floating action anchors, and primary headers.
- **Secondary Accent (`#3B82F6`)**: Bright electric cerulean for motivational character visuals, primary workout paths, and active navigation links.
- **Tertiary Warmth (`#FF6B4A`)**: Saturated coral orange dedicated to active streaks, calorie burns, and macro highlights.
- **Semantic Accents**:
  - Green Leaf (`#10B981`) for water logging, recovery, and completion metrics.
  - Amber Sun (`#F59E0B`) for carbohydrate indicators and VIP/Plus indicators.
  - Muted Charcoal / Gray Subdued (`#8E95A5`) for auxiliary metadata, units, and inactive indicators.

## Typography

Typography establishes instant readability through heavy numerical weightings alongside refined, balanced text layers. 

- **Primary Western Font**: Plus Jakarta Sans delivers geometric clarity and friendly organic apertures.
- **RTL & Persian Font Stack**: In Persian runtime environments, replace font tokens with `Vazirmatn, IRANSans, Plus Jakarta Sans, sans-serif`. Numerical displays take bold or black weights (`700`/`800`) to highlight calories, macro counts, and set volumes.
- **Display Weights & Metrics**: Primary counters (such as daily calorie balances) utilize `display-hero` with tight negative letter spacing (`-0.02em`) to ground attention immediately.
- **Secondary Labels**: Subtitles and metadata utilize `body-sm` or `label-md` rendered in muted slate (`#8E95A5`), keeping supporting context unobtrusive.

## Layout & Spacing

The layout embraces a mobile-first fluid container paradigm structured on a strict 4px/8px incremental base:
- **Canvas Margins**: Native lateral safe margins are locked to `1rem` (16px), extending to `1.25rem` (20px) on large screens.
- **Grid Architecture**: Multi-card dashboard structures employ a 2-column or asymmetric grid rhythm with an internal gutter of `0.75rem` (12px).
- **Component Padding**: Standard card internal padding is standardized to `1.25rem` (20px) horizontally and vertically, retaining generous negative space around large numerical telemetry.
- **Micro Gaps**: Compact macro trackers and circular pill badges leverage `space-xs` (4px) and `space-sm` (8px) for tightly coupled visual units.
- **Scroll Padding**: Extra bottom padding (`5rem` / 80px) is reserved across main viewports to prevent the floating bottom navigation dock from obscuring content.

## Elevation & Depth

This system avoids hard-bordered boxes and heavy dropshadows, relying on soft ambient diffusion to craft weightless, physical surfaces:

- **Level 0 (Canvas)**: `#F4F5F8` background base.
- **Level 1 (Card Containers)**: Pure white `#FFFFFF` surface elevated with an ultra-diffused ambient shadow: `box-shadow: 0 4px 20px -2px rgba(31, 35, 43, 0.04), 0 2px 6px -1px rgba(31, 35, 43, 0.02)`. No border lines are required on primary light screens.
- **Level 2 (Pill Badges & Buttons)**: Interactive surface buttons use either dark solid fill (`#1F232B`) or soft tint layers (`rgba(31, 35, 43, 0.04)`). Floating interactive pills employ a mild directional drop shadow: `box-shadow: 0 6px 16px -4px rgba(31, 35, 43, 0.12)`.
- **Level 3 (Floating Nav Dock)**: High blur glassmorphic or milk-white floating capsule: `background: rgba(255, 255, 255, 0.92)`, `backdrop-filter: blur(20px)`, and `box-shadow: 0 12px 32px -6px rgba(31, 35, 43, 0.08)`.

## Shapes

The shape hierarchy is deeply rounded, tactile, and playful:
- **Major Cards & Bento Pods**: Styled with extra-soft corners (`rounded-3xl`, spanning `24px` to `28px`).
- **Interactive Action Buttons & Filter Pills**: Fully rounded pill capsules (`border-radius: 9999px`).
- **Input Fields & Micro-Tags**: Styled with `rounded-2xl` (`16px`) to match the curvaceous visual vocabulary.
- **Icon Circles & Avatar Containers**: Perfect circular geometry (`50%` radius).

## Components

### Buttons
- **Primary Action (Dark Pill)**: Solid `#1F232B` background with `#FFFFFF` text and icons. Full pill radius (`9999px`), internal padding `12px 24px`. Subtle downward scale effect on tap (`active:scale-95`).
- **Secondary Action (Soft Ghost Pill)**: Light gray or soft tinted background (`#F4F5F8` or `rgba(31, 35, 43, 0.06)`), charcoal text, pill-shaped.
- **Floating Action Button (Hero Plus)**: Circular or pill-shaped `#1F232B` button placed either docked or offset within the navigation bar. Houses a bold white plus icon (`+`).

### Cards & Bento Pods
- **Nutrition Summary Bento**: Main calorie card paired beside stacked mini-cards (consumed vs. burned). Pure `#FFFFFF` surface with `26px` corner radius. Contains primary Persian/Latin numbers in `display-hero-mobile`.
- **Macro Nutrient Pods**: Segmented horizontal pill cards showcasing circular micro-progress rings (e.g., Carbs in `#FF6B4A`, Protein in `#EF4444`, Fats in `#F59E0B`), followed by numerical fractions (`consumed / target`).
- **Exercise / Workout Banner**: Horizontal split card featuring 3D character illustrations on one side, title, duration tag, and a nested `#1F232B` start button on the opposite side.

### Circular Progress Indicators
- Smooth SVG circular arcs with rounded stroke ends (`stroke-linecap: round`). 
- Gray rail path (`#E5E7EB` or `#F4F5F8`) under active accent stroke color, with stroke thickness between `4px` and `6px`.

### Bottom Floating Navigation Bar
- A detached floating island suspended `16px` above the bottom screen boundary.
- Encased in a `9999px` pill enclosure featuring a frosted white background (`rgba(255, 255, 255, 0.92)` with `backdrop-filter: blur(20px)`).
- Symmetrical layout featuring monochrome icon slots (`24px`), an elevated center active icon with an illuminated circular background, and an integrated floating quick-add button.

### Chips & Filter Pills
- Horizontal scrollable rows of category filters (e.g., Abs, Chest, Arms, Leg).
- Inactive state: `#FFFFFF` with muted text and subtle zero-elevation outline or soft surface.
- Active state: `#1F232B` background with `#FFFFFF` bold typography.

### Input Fields & Selectors
- Background color `#F4F5F8` nested within white cards, or white fields within background canvas.
- Fully rounded corners (`16px` to pill), no borders. Subtle focus ring with `rgba(59, 130, 246, 0.25)`.